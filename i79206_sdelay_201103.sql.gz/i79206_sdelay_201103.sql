-- MySQL dump 10.13  Distrib 5.6.35, for Linux (x86_64)
--
-- Host: localhost    Database: i79206_sdelay
-- ------------------------------------------------------
-- Server version	5.7.21-20-beget-5.7.21-20-1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `causer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `properties` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'materials','updated','App\\Models\\Material',23,NULL,NULL,'{\"old\": {\"price\": 26}, \"attributes\": {\"price\": 27}}','2020-10-12 12:25:14','2020-10-12 12:25:14'),(2,'materials','updated','App\\Models\\Material',23,NULL,NULL,'{\"old\": {\"slug\": \"ribbon_60\", \"price\": 27}, \"attributes\": {\"slug\": \"ribbon_601\", \"price\": 26}}','2020-10-12 12:25:29','2020-10-12 12:25:29'),(3,'materials','updated','App\\Models\\Material',23,NULL,NULL,'{\"old\": {\"slug\": \"ribbon_601\"}, \"attributes\": {\"slug\": \"ribbon_60\"}}','2020-10-12 12:25:37','2020-10-12 12:25:37'),(4,'materials','updated','App\\Models\\Material',23,'App\\User',1,'{\"old\": {\"price\": 26}, \"attributes\": {\"price\": 261}}','2020-10-12 12:27:40','2020-10-12 12:27:40'),(5,'materials','updated','App\\Models\\Material',23,'App\\User',1,'{\"old\": {\"price\": 261}, \"attributes\": {\"price\": 26}}','2020-10-12 12:27:47','2020-10-12 12:27:47'),(6,'fabric','updated','App\\Models\\Fabrics\\Fabric',64,'App\\User',1,'{\"old\": {\"color_number\": \"11\"}, \"attributes\": {\"color_number\": \"11-23\"}}','2020-10-16 08:34:58','2020-10-16 08:34:58'),(7,'FabricType','updated','App\\Models\\Fabrics\\FabricType',7,'App\\User',1,'{\"old\": {\"name\": \"Шенилл\"}, \"attributes\": {\"name\": \"Шенилл1\"}}','2020-10-16 08:41:26','2020-10-16 08:41:26'),(8,'FabricType','updated','App\\Models\\Fabrics\\FabricType',7,'App\\User',1,'{\"old\": {\"name\": \"Шенилл1\"}, \"attributes\": {\"name\": \"Шенилл\"}}','2020-10-16 08:41:31','2020-10-16 08:41:31'),(9,'fabric','updated','App\\Models\\Fabrics\\Fabric',64,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 10:58:47','2020-10-17 10:58:47'),(10,'fabric','updated','App\\Models\\Fabrics\\Fabric',63,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:03:03','2020-10-17 11:03:03'),(11,'fabric','updated','App\\Models\\Fabrics\\Fabric',62,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:06:13','2020-10-17 11:06:13'),(12,'fabric','updated','App\\Models\\Fabrics\\Fabric',63,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:06:42','2020-10-17 11:06:42'),(13,'fabric','updated','App\\Models\\Fabrics\\Fabric',1,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:12:46','2020-10-17 11:12:46'),(14,'fabric','updated','App\\Models\\Fabrics\\Fabric',2,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:25:50','2020-10-17 11:25:50'),(15,'fabric','updated','App\\Models\\Fabrics\\Fabric',3,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:26:00','2020-10-17 11:26:00'),(16,'fabric','updated','App\\Models\\Fabrics\\Fabric',4,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:26:09','2020-10-17 11:26:09'),(17,'fabric','updated','App\\Models\\Fabrics\\Fabric',5,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:26:19','2020-10-17 11:26:19'),(18,'fabric','updated','App\\Models\\Fabrics\\Fabric',6,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:26:29','2020-10-17 11:26:29'),(19,'fabric','updated','App\\Models\\Fabrics\\Fabric',7,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:26:40','2020-10-17 11:26:40'),(20,'fabric','updated','App\\Models\\Fabrics\\Fabric',8,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:26:54','2020-10-17 11:26:54'),(21,'fabric','updated','App\\Models\\Fabrics\\Fabric',9,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:27:06','2020-10-17 11:27:06'),(22,'fabric','updated','App\\Models\\Fabrics\\Fabric',10,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:27:16','2020-10-17 11:27:16'),(23,'fabric','updated','App\\Models\\Fabrics\\Fabric',11,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:27:30','2020-10-17 11:27:30'),(24,'fabric','updated','App\\Models\\Fabrics\\Fabric',12,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:27:39','2020-10-17 11:27:39'),(25,'fabric','updated','App\\Models\\Fabrics\\Fabric',13,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:27:48','2020-10-17 11:27:48'),(26,'fabric','updated','App\\Models\\Fabrics\\Fabric',14,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:28:24','2020-10-17 11:28:24'),(27,'fabric','updated','App\\Models\\Fabrics\\Fabric',15,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:28:33','2020-10-17 11:28:33'),(28,'fabric','updated','App\\Models\\Fabrics\\Fabric',16,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:28:42','2020-10-17 11:28:42'),(29,'fabric','updated','App\\Models\\Fabrics\\Fabric',17,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:28:56','2020-10-17 11:28:56'),(30,'fabric','updated','App\\Models\\Fabrics\\Fabric',18,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:29:35','2020-10-17 11:29:35'),(31,'fabric','updated','App\\Models\\Fabrics\\Fabric',19,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:29:50','2020-10-17 11:29:50'),(32,'fabric','updated','App\\Models\\Fabrics\\Fabric',20,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:30:03','2020-10-17 11:30:03'),(33,'fabric','updated','App\\Models\\Fabrics\\Fabric',21,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:33:24','2020-10-17 11:33:24'),(34,'fabric','updated','App\\Models\\Fabrics\\Fabric',22,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:33:34','2020-10-17 11:33:34'),(35,'fabric','updated','App\\Models\\Fabrics\\Fabric',23,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:33:44','2020-10-17 11:33:44'),(36,'fabric','updated','App\\Models\\Fabrics\\Fabric',24,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:33:54','2020-10-17 11:33:54'),(37,'fabric','updated','App\\Models\\Fabrics\\Fabric',25,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:34:07','2020-10-17 11:34:07'),(38,'fabric','updated','App\\Models\\Fabrics\\Fabric',26,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:34:31','2020-10-17 11:34:31'),(39,'fabric','updated','App\\Models\\Fabrics\\Fabric',27,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:34:43','2020-10-17 11:34:43'),(40,'fabric','updated','App\\Models\\Fabrics\\Fabric',28,'App\\User',1,'{\"old\": [], \"attributes\": []}','2020-10-17 11:34:53','2020-10-17 11:34:53'),(41,'fabric','updated','App\\Models\\Fabrics\\Fabric',37,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/e8b0f6574d858659a21858b303fb0476.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(42,'fabric','updated','App\\Models\\Fabrics\\Fabric',19,NULL,NULL,'{\"old\": {\"image\": \"fabrics/187a58f8c0be9f4f2898d16bf227c624.jpg\"}, \"attributes\": {\"image\": \"fabrics/1426a4044cd4a5e4577e550e192358c8.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(43,'fabric','updated','App\\Models\\Fabrics\\Fabric',11,NULL,NULL,'{\"old\": {\"image\": \"fabrics/0778aa6778dda3187f91abc233c7d0a4.jpg\"}, \"attributes\": {\"image\": \"fabrics/374ef9d8da8ac368ec1b72b0dd72b9a3.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(44,'fabric','updated','App\\Models\\Fabrics\\Fabric',20,NULL,NULL,'{\"old\": {\"image\": \"fabrics/769ae6a698c6d2c6d60f639ce791d530.jpg\"}, \"attributes\": {\"image\": \"fabrics/7dc95d196a20fee617a55bc7f8b3898d.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(45,'fabric','updated','App\\Models\\Fabrics\\Fabric',32,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/1689c6459d046fd9ce4087b99ca549b8.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(46,'fabric','updated','App\\Models\\Fabrics\\Fabric',44,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/724b5447c0605bb85182a913646eca7b.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(47,'fabric','updated','App\\Models\\Fabrics\\Fabric',3,NULL,NULL,'{\"old\": {\"image\": \"fabrics/33e14d7185bd37dbcf7184db670931f1.jpg\"}, \"attributes\": {\"image\": \"fabrics/987aceaae59d3100ec74b296d266610e.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(48,'fabric','updated','App\\Models\\Fabrics\\Fabric',2,NULL,NULL,'{\"old\": {\"image\": \"fabrics/adeeaec52e32808b1f3bc37782b54c60.jpg\"}, \"attributes\": {\"image\": \"fabrics/989bc7769baacbe71f2336b18390fd0a.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(49,'fabric','updated','App\\Models\\Fabrics\\Fabric',54,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/7299433758179a1d35ee5058f8164edd.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(50,'fabric','updated','App\\Models\\Fabrics\\Fabric',28,NULL,NULL,'{\"old\": {\"image\": \"fabrics/8e54761d8edd833bce1023ac1bab0e17.jpg\"}, \"attributes\": {\"image\": \"fabrics/a76bd05c55cb85489243a324f67d213f.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(51,'fabric','updated','App\\Models\\Fabrics\\Fabric',5,NULL,NULL,'{\"old\": {\"image\": \"fabrics/798f7f9f5c8b03f08f10db19d0194b86.jpg\"}, \"attributes\": {\"image\": \"fabrics/cfcd138ce30ee5d7cd47034634886656.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(52,'fabric','updated','App\\Models\\Fabrics\\Fabric',4,NULL,NULL,'{\"old\": {\"image\": \"fabrics/c37780f641ec6968feee57ac5fa6945a.jpg\"}, \"attributes\": {\"image\": \"fabrics/532b90e4b1d9f42890bebe3700dd3b3b.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(53,'fabric','updated','App\\Models\\Fabrics\\Fabric',58,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/33d78cc9af488e4db700f0893d159fea.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(54,'fabric','updated','App\\Models\\Fabrics\\Fabric',27,NULL,NULL,'{\"old\": {\"image\": \"fabrics/54728beb6c3371735a54af066f3d6218.jpg\"}, \"attributes\": {\"image\": \"fabrics/5bb5403f654fc328f44011fd649697d8.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(55,'fabric','updated','App\\Models\\Fabrics\\Fabric',15,NULL,NULL,'{\"old\": {\"image\": \"fabrics/33341b9e4b74e0e52290071942d4dc38.jpg\"}, \"attributes\": {\"image\": \"fabrics/47341705d20f7072c1e9b01391f2bc23.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(56,'fabric','updated','App\\Models\\Fabrics\\Fabric',16,NULL,NULL,'{\"old\": {\"image\": \"fabrics/c792e6e6836024c49fa9e0d196036a67.jpg\"}, \"attributes\": {\"image\": \"fabrics/190d59f94d3d4968f1905908d3c9a611.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(57,'fabric','updated','App\\Models\\Fabrics\\Fabric',57,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/d8f02bb0fb6cfa442d2a75b08563592a.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(58,'fabric','updated','App\\Models\\Fabrics\\Fabric',55,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/cfd3c38b7d2ead8f34a7809a66b6c0fa.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(59,'fabric','updated','App\\Models\\Fabrics\\Fabric',50,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/ef4bbf0fc53e3344910f4f0a8bffe45c.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(60,'fabric','updated','App\\Models\\Fabrics\\Fabric',51,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/7baf44c238d395c26fab380a666c0720.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(61,'fabric','updated','App\\Models\\Fabrics\\Fabric',1,NULL,NULL,'{\"old\": {\"image\": \"fabrics/5d76b5855026174d4cd3121fc65a7557.jpg\"}, \"attributes\": {\"image\": \"fabrics/76a0b9581172542d2b8f9e2f7173db96.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(62,'fabric','updated','App\\Models\\Fabrics\\Fabric',29,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/d8736dad412193bd6e1773c977fb850a.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(63,'fabric','updated','App\\Models\\Fabrics\\Fabric',21,NULL,NULL,'{\"old\": {\"image\": \"fabrics/882cb56473e3cccdf7fe75b3b32689a3.jpg\"}, \"attributes\": {\"image\": \"fabrics/8125759a115a2853fc0b94c839f3d69c.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(64,'fabric','updated','App\\Models\\Fabrics\\Fabric',22,NULL,NULL,'{\"old\": {\"image\": \"fabrics/07dcbcffcf5eb0f319c35a96576e61fd.jpg\"}, \"attributes\": {\"image\": \"fabrics/09901e3ffd7d612b2231a707fdee2a8d.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(65,'fabric','updated','App\\Models\\Fabrics\\Fabric',48,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/607c2a14cd5e455e1304b74e2bddc515.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(66,'fabric','updated','App\\Models\\Fabrics\\Fabric',10,NULL,NULL,'{\"old\": {\"image\": \"fabrics/016547c93f7109b896fb422529b958bb.jpg\"}, \"attributes\": {\"image\": \"fabrics/a19cfe7ea387c951f16f6d30d7f52163.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(67,'fabric','updated','App\\Models\\Fabrics\\Fabric',38,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/21bc4262cded37368fd2cfa9a3bff38c.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(68,'fabric','updated','App\\Models\\Fabrics\\Fabric',17,NULL,NULL,'{\"old\": {\"image\": \"fabrics/45cba6972121b94c6f94fa0134de532c.jpg\"}, \"attributes\": {\"image\": \"fabrics/71739b70b17036e1a8deb3d58e9e7ad4.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(69,'fabric','updated','App\\Models\\Fabrics\\Fabric',42,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/7d2bb159bf0354707b679e4f937f0936.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(70,'fabric','updated','App\\Models\\Fabrics\\Fabric',40,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/e503ab845efae0431d91b3d98b0fc374.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(71,'fabric','updated','App\\Models\\Fabrics\\Fabric',12,NULL,NULL,'{\"old\": {\"image\": \"fabrics/0d2c2633cee58cc5e4e36cd044e9ef20.jpg\"}, \"attributes\": {\"image\": \"fabrics/15d37be35b45257054650d14c998b1c3.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(72,'fabric','updated','App\\Models\\Fabrics\\Fabric',30,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/98570852333a5fb9a6611a01182809ab.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(73,'fabric','updated','App\\Models\\Fabrics\\Fabric',23,NULL,NULL,'{\"old\": {\"image\": \"fabrics/00ea7e3bd1eb40ce5af7c4595fb402ca.jpg\"}, \"attributes\": {\"image\": \"fabrics/fbd9c8801520b99279e7aeed533fe827.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(74,'fabric','updated','App\\Models\\Fabrics\\Fabric',45,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/5c5ac2ab6e8c1a41fd27af5103ecbf43.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(75,'fabric','updated','App\\Models\\Fabrics\\Fabric',52,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/720d7c5c805ea09f5d3ac70b8fdb9342.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(76,'fabric','updated','App\\Models\\Fabrics\\Fabric',13,NULL,NULL,'{\"old\": {\"image\": \"fabrics/a373141f408b42be5dafe7039b74ac0f.jpg\"}, \"attributes\": {\"image\": \"fabrics/b435202f9d157703831e6a7b6b13baa7.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(77,'fabric','updated','App\\Models\\Fabrics\\Fabric',39,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/75a9969fe8b4e64427ffe35e37ddd7a2.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(78,'fabric','updated','App\\Models\\Fabrics\\Fabric',35,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/0a1f5d0197e58db0f6e966cd62a00027.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(79,'fabric','updated','App\\Models\\Fabrics\\Fabric',14,NULL,NULL,'{\"old\": {\"image\": \"fabrics/cfb8c98ded00f0c43cd2f42839e3765d.jpg\"}, \"attributes\": {\"image\": \"fabrics/d54e7b9e270a6961da70644f94331fac.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(80,'fabric','updated','App\\Models\\Fabrics\\Fabric',47,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/526d95901ac69483d8951bc2d086658d.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(81,'fabric','updated','App\\Models\\Fabrics\\Fabric',49,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/cbe2b6a6d9610266b836bedb0683f6e7.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(82,'fabric','updated','App\\Models\\Fabrics\\Fabric',43,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/3c2b0102bdb637cf67c44786d644617e.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(83,'fabric','updated','App\\Models\\Fabrics\\Fabric',59,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/a8c361c37f0dbad50c116fe69f8bbb66.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(84,'fabric','updated','App\\Models\\Fabrics\\Fabric',9,NULL,NULL,'{\"old\": {\"image\": \"fabrics/da58ec3525cd11117922d6491cf7b03e.jpg\"}, \"attributes\": {\"image\": \"fabrics/5717cac9a65bc007c96a8c78b84e0e2f.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(85,'fabric','updated','App\\Models\\Fabrics\\Fabric',6,NULL,NULL,'{\"old\": {\"image\": \"fabrics/5fe30e1604a39e37aa0de6b3f03bdbc0.jpg\"}, \"attributes\": {\"image\": \"fabrics/46052d63bddec1d425c3a6a1ec2c1f96.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(86,'fabric','updated','App\\Models\\Fabrics\\Fabric',31,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/7ef9758c350e192e6d21b3892532f8c7.jpg\"}}','2020-10-18 09:56:08','2020-10-18 09:56:08'),(87,'fabric','updated','App\\Models\\Fabrics\\Fabric',56,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/37c1f1adbdd44ba2afcc0767f0e5b5e1.jpg\"}}','2020-10-18 09:56:09','2020-10-18 09:56:09'),(88,'fabric','updated','App\\Models\\Fabrics\\Fabric',41,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/11716bf1bd926c5fb279ac62afa52df9.jpg\"}}','2020-10-18 09:56:09','2020-10-18 09:56:09'),(89,'fabric','updated','App\\Models\\Fabrics\\Fabric',53,NULL,NULL,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/3951dd90e5c3f9e172c2721a0e3437da.jpg\"}}','2020-10-18 09:56:09','2020-10-18 09:56:09'),(90,'fabric','updated','App\\Models\\Fabrics\\Fabric',62,'App\\User',1,'{\"old\": {\"image\": \"fabrics/b5d44a20e591d51ff849819b6b6839b5.jpg\"}, \"attributes\": {\"image\": \"/tmp/phpQZfFIB\"}}','2020-10-18 10:03:57','2020-10-18 10:03:57'),(91,'fabric','updated','App\\Models\\Fabrics\\Fabric',62,'App\\User',1,'{\"old\": {\"image\": \"/tmp/phpQZfFIB\"}, \"attributes\": {\"image\": \"fabrics/9aa3544817a7cb9f82457738edcad4a7.jpg\"}}','2020-10-18 10:04:43','2020-10-18 10:04:43'),(92,'fabric','updated','App\\Models\\Fabrics\\Fabric',61,'App\\User',1,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/ac845c2ea9a255d8b1fe8d71d9d628ae.jpg\"}}','2020-10-18 10:06:01','2020-10-18 10:06:01'),(93,'fabric','updated','App\\Models\\Fabrics\\Fabric',60,'App\\User',1,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/ef719b208f1331e907a365f9cd80b918.jpg\"}}','2020-10-18 10:07:57','2020-10-18 10:07:57'),(94,'fabric','updated','App\\Models\\Fabrics\\Fabric',46,'App\\User',1,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/dd1b0954a20093a49928f9d418441f86.jpg\"}}','2020-10-18 10:11:55','2020-10-18 10:11:55'),(95,'fabric','updated','App\\Models\\Fabrics\\Fabric',36,'App\\User',1,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/c8f0b8e8ddf6a9d7dbe3cfc584932615.jpg\"}}','2020-10-18 10:13:08','2020-10-18 10:13:08'),(96,'fabric','updated','App\\Models\\Fabrics\\Fabric',33,'App\\User',1,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/4c785fcb79c5cae22675edf1de64619a.jpg\"}}','2020-10-18 10:14:21','2020-10-18 10:14:21'),(97,'fabric','updated','App\\Models\\Fabrics\\Fabric',34,'App\\User',1,'{\"old\": {\"image\": null}, \"attributes\": {\"image\": \"fabrics/2e14b0e6019ac08633842dcc919f37cc.jpg\"}}','2020-10-18 10:14:32','2020-10-18 10:14:32'),(98,'FabricType','updated','App\\Models\\Fabrics\\FabricType',2,'App\\User',1,'{\"old\": {\"name\": \"Велюр dddddddd ыва\"}, \"attributes\": {\"name\": \"Велюр\"}}','2020-10-18 10:14:57','2020-10-18 10:14:57');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_attributes` text COLLATE utf8mb4_unicode_ci,
  `parent_id` int(11) DEFAULT '0',
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `estimate_work` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Диваны','[\"configuration\",\"mechanism\",\"dimensions\",\"legs\",\"texture\",\"softness_sofa\",\"fabric_color\"]',0,NULL,NULL,NULL,'[\"1\",\"3\",\"9\",\"8\",\"7\",\"5\",\"2\",\"6\",\"4\"]','2020-10-07 07:20:35','2020-10-19 05:10:22'),(3,'ДЕТСКАЯ','[\"configuration\",\"dimensions\"]',0,NULL,NULL,NULL,NULL,'2020-10-07 07:20:50','2020-10-08 04:08:13'),(4,'МЕБЕЛЬ',NULL,0,NULL,NULL,NULL,NULL,'2020-10-07 07:20:55','2020-10-07 07:20:55'),(5,'КРЕСЛА',NULL,0,NULL,NULL,NULL,NULL,'2020-10-07 07:21:00','2020-10-07 07:21:00'),(6,'ТУМБЫ','[\"legs\"]',0,NULL,NULL,NULL,NULL,'2020-10-07 07:21:07','2020-10-08 04:05:55'),(8,'КРОВАТИ','[\"mechanism\",\"dimensions\",\"softness_sofa\",\"color\"]',0,NULL,NULL,NULL,NULL,'2020-10-07 09:22:44','2020-10-18 10:23:42');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collections`
--

DROP TABLE IF EXISTS `collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collections`
--

LOCK TABLES `collections` WRITE;
/*!40000 ALTER TABLE `collections` DISABLE KEYS */;
INSERT INTO `collections` VALUES (1,'carboniopera',NULL,'2020-10-13 05:42:59','2020-10-13 05:42:59'),(2,'carboniplacida',NULL,'2020-10-13 05:43:05','2020-10-13 05:43:05'),(3,'chanel',NULL,'2020-10-13 05:43:14','2020-10-13 05:43:14'),(4,'idol',NULL,'2020-10-13 05:43:17','2020-10-13 05:43:17'),(5,'jute',NULL,'2020-10-13 05:43:20','2020-10-13 05:43:20'),(6,'manhattan',NULL,'2020-10-13 05:43:23','2020-10-13 05:43:23'),(7,'miss',NULL,'2020-10-13 05:43:26','2020-10-13 05:43:26'),(8,'ocean',NULL,'2020-10-13 05:43:29','2020-10-13 05:43:29'),(9,'polo',NULL,'2020-10-13 05:43:32','2020-10-13 05:43:32'),(10,'runa',NULL,'2020-10-13 05:43:35','2020-10-13 05:43:35'),(11,'runasaga',NULL,'2020-10-13 05:43:40','2020-10-16 08:50:14');
/*!40000 ALTER TABLE `collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `colors`
--

DROP TABLE IF EXISTS `colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `colors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eng` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colors`
--

LOCK TABLES `colors` WRITE;
/*!40000 ALTER TABLE `colors` DISABLE KEYS */;
INSERT INTO `colors` VALUES (1,'Бирюзовый','Turquoise',NULL,NULL,NULL),(2,'Бордовый','Burgundy',NULL,NULL,NULL),(3,'Голубой','Blue',NULL,NULL,NULL),(4,'Зеленый','Green',NULL,NULL,NULL),(5,'Кирпичный','Brick',NULL,NULL,NULL),(6,'Коричневый','Brown',NULL,NULL,NULL),(7,'Красный','Red',NULL,NULL,NULL),(8,'Оранжевый','Orange',NULL,NULL,NULL),(9,'Розовый','Pink',NULL,'2020-10-13 15:28:59','2020-10-13 15:29:02'),(10,'Светлый','Light',NULL,NULL,NULL),(11,'Серый','Grey',NULL,NULL,NULL),(12,'Синий','Blue',NULL,NULL,NULL),(13,'Темный','Dark',NULL,NULL,NULL),(14,'Фиолетовый','Violet',NULL,NULL,NULL),(15,'Хаки','Khaki',NULL,NULL,NULL),(16,'Черный','Black',NULL,NULL,NULL),(17,'Яркий','Bright',NULL,NULL,NULL),(18,'Бежевый',' Beige',NULL,NULL,NULL),(19,'Белый','White',NULL,NULL,'2020-10-16 08:41:43');
/*!40000 ALTER TABLE `colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration_colors`
--

DROP TABLE IF EXISTS `configuration_colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration_colors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT '0',
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration_colors`
--

LOCK TABLES `configuration_colors` WRITE;
/*!40000 ALTER TABLE `configuration_colors` DISABLE KEYS */;
INSERT INTO `configuration_colors` VALUES (1,'Красный',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:11:51','2020-10-07 05:11:51'),(2,'Синий',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:11:57','2020-10-07 05:11:57'),(3,'Зеленый',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:12:03','2020-10-07 05:12:03'),(4,'Черный',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:12:08','2020-10-07 05:12:08');
/*!40000 ALTER TABLE `configuration_colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration_legs`
--

DROP TABLE IF EXISTS `configuration_legs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration_legs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT '0',
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration_legs`
--

LOCK TABLES `configuration_legs` WRITE;
/*!40000 ALTER TABLE `configuration_legs` DISABLE KEYS */;
INSERT INTO `configuration_legs` VALUES (1,'Н1',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:19:06','2020-10-07 05:19:06'),(2,'Н2',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:19:11','2020-10-07 05:19:11'),(3,'Н3',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:19:16','2020-10-07 05:19:16');
/*!40000 ALTER TABLE `configuration_legs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration_mechanisms`
--

DROP TABLE IF EXISTS `configuration_mechanisms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration_mechanisms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT '0',
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration_mechanisms`
--

LOCK TABLES `configuration_mechanisms` WRITE;
/*!40000 ALTER TABLE `configuration_mechanisms` DISABLE KEYS */;
INSERT INTO `configuration_mechanisms` VALUES (1,'Без механизма',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:17:27','2020-10-07 05:17:27'),(2,'С механизмом',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:17:35','2020-10-07 05:17:35');
/*!40000 ALTER TABLE `configuration_mechanisms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration_settings`
--

DROP TABLE IF EXISTS `configuration_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(10) unsigned DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0',
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration_settings`
--

LOCK TABLES `configuration_settings` WRITE;
/*!40000 ALTER TABLE `configuration_settings` DISABLE KEYS */;
INSERT INTO `configuration_settings` VALUES (1,'Левосторонний диван',NULL,NULL,4,5,1,NULL,'2020-10-07 04:36:07','2020-10-07 04:37:02'),(2,'Правосторонний диван',NULL,NULL,2,3,1,NULL,'2020-10-07 04:36:56','2020-10-07 04:37:02');
/*!40000 ALTER TABLE `configuration_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration_sizes`
--

DROP TABLE IF EXISTS `configuration_sizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration_sizes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT '0',
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration_sizes`
--

LOCK TABLES `configuration_sizes` WRITE;
/*!40000 ALTER TABLE `configuration_sizes` DISABLE KEYS */;
INSERT INTO `configuration_sizes` VALUES (1,'1400мм',0,0,NULL,NULL,NULL,NULL,'2020-10-07 04:47:55','2020-10-07 04:48:48'),(2,'1600мм',0,0,NULL,NULL,NULL,NULL,'2020-10-07 04:47:55','2020-10-07 04:48:48'),(3,'1800мм',0,0,NULL,NULL,NULL,NULL,'2020-10-07 04:47:55','2020-10-07 04:48:48'),(4,'2000мм',0,0,NULL,NULL,NULL,NULL,'2020-10-07 04:47:55','2020-10-07 04:48:48'),(5,'2200мм',0,0,NULL,NULL,NULL,NULL,'2020-10-07 04:47:55','2020-10-07 04:48:48'),(6,'2400мм',0,0,NULL,NULL,NULL,NULL,'2020-10-07 04:47:55','2020-10-07 04:48:48'),(7,'2600мм',0,0,NULL,NULL,NULL,NULL,'2020-10-07 04:47:55','2020-10-07 04:48:48'),(8,'2800мм',0,0,NULL,NULL,NULL,NULL,'2020-10-07 04:47:55','2020-10-07 04:48:48');
/*!40000 ALTER TABLE `configuration_sizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration_softness_sofas`
--

DROP TABLE IF EXISTS `configuration_softness_sofas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration_softness_sofas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT '0',
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration_softness_sofas`
--

LOCK TABLES `configuration_softness_sofas` WRITE;
/*!40000 ALTER TABLE `configuration_softness_sofas` DISABLE KEYS */;
INSERT INTO `configuration_softness_sofas` VALUES (1,'Мягкий',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:20:29','2020-10-07 05:20:29'),(2,'Средний',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:20:35','2020-10-07 05:20:35'),(3,'Жесткий',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:20:42','2020-10-07 05:20:42');
/*!40000 ALTER TABLE `configuration_softness_sofas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration_textures`
--

DROP TABLE IF EXISTS `configuration_textures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration_textures` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT '0',
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration_textures`
--

LOCK TABLES `configuration_textures` WRITE;
/*!40000 ALTER TABLE `configuration_textures` DISABLE KEYS */;
INSERT INTO `configuration_textures` VALUES (1,'Шенил',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:15:21','2020-10-07 05:15:21'),(2,'Велюр',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:15:28','2020-10-07 05:15:28'),(3,'Рогожка',0,0,NULL,NULL,NULL,NULL,'2020-10-07 05:15:36','2020-10-07 05:15:36');
/*!40000 ALTER TABLE `configuration_textures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimate_works`
--

DROP TABLE IF EXISTS `estimate_works`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estimate_works` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` tinyint(1) NOT NULL,
  `threshold` int(10) unsigned NOT NULL DEFAULT '0',
  `first` int(10) unsigned NOT NULL DEFAULT '0',
  `second` int(10) unsigned NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimate_works`
--

LOCK TABLES `estimate_works` WRITE;
/*!40000 ALTER TABLE `estimate_works` DISABLE KEYS */;
INSERT INTO `estimate_works` VALUES (1,'Каркасник','wireframe',1,2200,1000,1500,NULL,'2020-10-19 00:24:57','2020-10-19 00:24:57'),(2,'Обивщик','upholsterer',1,2200,1500,2500,NULL,'2020-10-19 00:25:38','2020-10-19 00:25:38'),(3,'Столяр','carpenter',0,1,5000,0,NULL,'2020-10-19 00:27:36','2020-10-19 00:27:36'),(4,'Сварщик','welder',0,1,1500,0,NULL,'2020-10-19 00:31:57','2020-10-19 00:31:57'),(5,'Швея','seamstress',1,2200,1500,2500,NULL,'2020-10-19 00:32:22','2020-10-19 00:32:22'),(6,'Аренда','rent',1,2200,2500,5000,NULL,'2020-10-19 00:32:49','2020-10-19 00:32:49'),(7,'Упаковка','packaging',1,2200,1000,1500,NULL,'2020-10-19 00:33:09','2020-10-19 00:33:09'),(8,'Доставка','delivery',1,2200,1000,1500,NULL,'2020-10-19 00:33:30','2020-10-19 00:33:30'),(9,'Сварка','welding',0,0,1000,1000,NULL,'2020-10-19 00:33:46','2020-10-19 00:33:46');
/*!40000 ALTER TABLE `estimate_works` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fabrics`
--

DROP TABLE IF EXISTS `fabrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fabrics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `producer_id` int(10) unsigned DEFAULT NULL,
  `fabrics_type_id` int(10) unsigned DEFAULT NULL,
  `collection_id` int(10) unsigned DEFAULT NULL,
  `base_color_id` int(10) unsigned DEFAULT NULL,
  `dop_color_id` int(10) unsigned DEFAULT NULL,
  `add_color_id` int(10) unsigned DEFAULT NULL,
  `name_site` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fabric_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color_number` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_site` (`name_site`),
  UNIQUE KEY `fabric_code` (`fabric_code`),
  KEY `fabrics_producer_id_foreign` (`producer_id`),
  KEY `fabrics_color_id_foreign` (`base_color_id`),
  KEY `fabrics_collection_id_foreign` (`collection_id`),
  KEY `fabrics_dop_color_id_foreign` (`add_color_id`),
  KEY `fabrics_fabrics_type_id_foreign` (`fabrics_type_id`),
  KEY `fabrics_sub_dop_color_id_foreign` (`dop_color_id`),
  CONSTRAINT `fabrics_collection_id_foreign` FOREIGN KEY (`collection_id`) REFERENCES `collections` (`id`),
  CONSTRAINT `fabrics_color_id_foreign` FOREIGN KEY (`base_color_id`) REFERENCES `colors` (`id`),
  CONSTRAINT `fabrics_dop_color_id_foreign` FOREIGN KEY (`add_color_id`) REFERENCES `colors` (`id`),
  CONSTRAINT `fabrics_fabrics_type_id_foreign` FOREIGN KEY (`fabrics_type_id`) REFERENCES `fabrics_types` (`id`),
  CONSTRAINT `fabrics_producer_id_foreign` FOREIGN KEY (`producer_id`) REFERENCES `producers` (`id`),
  CONSTRAINT `fabrics_sub_dop_color_id_foreign` FOREIGN KEY (`dop_color_id`) REFERENCES `colors` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fabrics`
--

LOCK TABLES `fabrics` WRITE;
/*!40000 ALTER TABLE `fabrics` DISABLE KEYS */;
INSERT INTO `fabrics` VALUES (1,1,7,10,16,13,NULL,'Runa_10_rapport','TD_runa_10','10',1118,'fabrics/76a0b9581172542d2b8f9e2f7173db96.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(2,1,7,10,18,10,NULL,'Runa_6_rapport','TD_runa_6','6',1118,'fabrics/989bc7769baacbe71f2336b18390fd0a.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(3,1,7,10,6,13,NULL,'Runa_5_rapport','TD_runa_5','5',1118,'fabrics/987aceaae59d3100ec74b296d266610e.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(4,1,7,10,12,13,NULL,'Runa_4_rapport','TD_runa_4','4',1118,'fabrics/532b90e4b1d9f42890bebe3700dd3b3b.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(5,1,7,10,11,13,NULL,'Runa_3_rapport','TD_runa_3','3',1118,'fabrics/cfcd138ce30ee5d7cd47034634886656.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(6,1,7,10,18,13,NULL,'Runa_2_rapport','TD_runa_2','2',1118,'fabrics/46052d63bddec1d425c3a6a1ec2c1f96.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(7,1,7,10,4,13,15,'Runa_7_rapport','TD_runa_7','7',1118,'fabrics/1640e18cff3a080a8c9047a159200e45.jpg','2020-10-14 12:35:31','2020-10-17 11:26:40'),(8,1,7,11,18,10,NULL,'Runa_saga_1_rapport','TD_runasaga_1','1',1118,'fabrics/0cb39b4e49b835cc826cfc4fb95cb633.jpg','2020-10-14 12:35:31','2020-10-17 11:26:54'),(9,1,7,9,12,13,NULL,'polo_14_rapport','TD_polo_14','14',678,'fabrics/5717cac9a65bc007c96a8c78b84e0e2f.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(10,1,7,9,6,13,NULL,'polo_12_rapport','TD_polo_12','12',678,'fabrics/a19cfe7ea387c951f16f6d30d7f52163.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(11,1,7,9,4,13,15,'polo_11_rapport','TD_polo_11','11',678,'fabrics/374ef9d8da8ac368ec1b72b0dd72b9a3.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(12,1,7,9,18,10,NULL,'polo_9_rapport','TD_polo_9','9',678,'fabrics/15d37be35b45257054650d14c998b1c3.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(13,1,7,9,14,10,NULL,'polo_8_rapport','TD_polo_8','8',678,'fabrics/b435202f9d157703831e6a7b6b13baa7.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(14,1,7,9,18,10,NULL,'polo_7_rapport','TD_polo_7','7',678,'fabrics/d54e7b9e270a6961da70644f94331fac.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(15,1,7,9,6,13,NULL,'polo_5_rapport','TD_polo_5','5',678,'fabrics/47341705d20f7072c1e9b01391f2bc23.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(16,1,7,9,18,10,NULL,'polo_1_rapport','TD_polo_1','1',678,'fabrics/190d59f94d3d4968f1905908d3c9a611.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(17,1,5,8,6,13,NULL,'ocean_9_rapport','TD_ocean_9','9',790,'fabrics/71739b70b17036e1a8deb3d58e9e7ad4.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(18,1,5,8,18,10,NULL,'ocean_1_rapport','TD_ocean_1','1',790,'fabrics/90d94b6612990261ee397303c28cf86d.jpg','2020-10-14 12:35:31','2020-10-17 11:29:35'),(19,1,5,8,4,13,15,'ocean_5_rapport','TD_ocean_5','5',790,'fabrics/1426a4044cd4a5e4577e550e192358c8.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(20,1,5,8,6,13,NULL,'ocean_3_rapport','TD_ocean_3','3',790,'fabrics/7dc95d196a20fee617a55bc7f8b3898d.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(21,1,5,8,6,13,5,'Ocaen_16_rapport','TD_ocean_16','16',790,'fabrics/8125759a115a2853fc0b94c839f3d69c.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(22,1,5,8,11,13,NULL,'Ocaen_15_rapport','TD_ocean_15','15',790,'fabrics/09901e3ffd7d612b2231a707fdee2a8d.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(23,1,5,8,18,10,NULL,'Ocaen_11_rapport','TD_ocean_11','11',790,'fabrics/fbd9c8801520b99279e7aeed533fe827.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(24,1,5,8,11,10,NULL,'Ocaen_12_rapport','TD_ocean_12','12',790,'fabrics/a9de8bf0551d8d539f790610af48d408.jpg','2020-10-14 12:35:31','2020-10-17 11:33:54'),(25,1,5,8,18,10,NULL,'Ocaen_2_rapport','TD_ocean_2','2',790,'fabrics/f7920a63e7dc23f4c6bb255c43ea05d0.jpg','2020-10-14 12:35:31','2020-10-17 11:34:07'),(26,1,5,8,12,13,NULL,'Ocaen_6_rapport','TD_ocean_6','6',790,'fabrics/35179e51cf1a00e5cdbe90d6c94801d9.jpg','2020-10-14 12:35:31','2020-10-17 11:34:31'),(27,1,7,7,18,10,NULL,'Miss_101','TD_miss_101','101',819,'fabrics/5bb5403f654fc328f44011fd649697d8.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(28,1,7,7,8,17,NULL,'Miss_35','TD_miss_35','35',819,'fabrics/a76bd05c55cb85489243a324f67d213f.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(29,1,7,7,18,10,NULL,'Miss_33','TD_miss_33','33',819,'fabrics/d8736dad412193bd6e1773c977fb850a.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(30,1,7,7,11,10,NULL,'Miss_32','TD_miss_32','32',819,'fabrics/98570852333a5fb9a6611a01182809ab.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(31,1,7,7,14,17,NULL,'Miss_21','TD_miss_21','21',819,'fabrics/7ef9758c350e192e6d21b3892532f8c7.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(32,1,7,7,3,17,NULL,'Miss_16','TD_miss_16','16',819,'fabrics/1689c6459d046fd9ce4087b99ca549b8.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(33,1,7,7,19,10,NULL,'Miss_01','TD_miss_1','1',819,'fabrics/4c785fcb79c5cae22675edf1de64619a.jpg','2020-10-14 12:35:31','2020-10-18 10:14:21'),(34,1,7,7,11,10,NULL,'Miss_09','TD_miss_9','9',819,'fabrics/2e14b0e6019ac08633842dcc919f37cc.jpg','2020-10-14 12:35:31','2020-10-18 10:14:32'),(35,1,2,6,16,13,NULL,'manhattan_23_rapport','TD_manhattan_23','23',962,'fabrics/0a1f5d0197e58db0f6e966cd62a00027.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(36,1,2,6,2,13,NULL,'manhattan_22_rapport','TD_manhattan_22','22',962,'fabrics/c8f0b8e8ddf6a9d7dbe3cfc584932615.jpg','2020-10-14 12:35:31','2020-10-18 10:13:08'),(37,1,2,6,2,13,NULL,'manhattan_19_rapport','TD_manhattan_19','19',962,'fabrics/e8b0f6574d858659a21858b303fb0476.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(38,1,2,6,12,13,NULL,'manhattan_18_rapport','TD_manhattan_18','18',962,'fabrics/21bc4262cded37368fd2cfa9a3bff38c.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(39,1,2,6,4,13,NULL,'manhattan_16_rapport','TD_manhattan_16','16',962,'fabrics/75a9969fe8b4e64427ffe35e37ddd7a2.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(40,1,2,6,6,13,NULL,'manhattan_9_rapport','TD_manhattan_9','9',962,'fabrics/e503ab845efae0431d91b3d98b0fc374.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(41,1,2,6,18,13,NULL,'manhattan_7_rapport','TD_manhattan_7','7',962,'fabrics/11716bf1bd926c5fb279ac62afa52df9.jpg','2020-10-14 12:35:31','2020-10-18 09:56:09'),(42,1,2,6,11,13,NULL,'Manhattan_6_rapport','TD_manhattan_6','6',962,'fabrics/7d2bb159bf0354707b679e4f937f0936.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(43,1,2,6,18,10,NULL,'manhattan_5_rapport','TD_manhattan_5','5',962,'fabrics/3c2b0102bdb637cf67c44786d644617e.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(44,1,2,6,9,10,NULL,'manhattan_4_rapport','TD_manhattan_4','4',962,'fabrics/724b5447c0605bb85182a913646eca7b.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(45,1,2,6,11,10,NULL,'Manhattan_1_rapport','TD_manhattan_1','1',962,'fabrics/5c5ac2ab6e8c1a41fd27af5103ecbf43.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(46,1,2,6,12,13,NULL,'Manhattan_12_rapport','TD_manhattan_12','12',962,'fabrics/dd1b0954a20093a49928f9d418441f86.jpg','2020-10-14 12:35:31','2020-10-18 10:11:55'),(47,1,6,5,4,13,NULL,'jute_29_rapport','TD_jute_29','29',993,'fabrics/526d95901ac69483d8951bc2d086658d.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(48,1,6,5,6,13,NULL,'jute_25_rapport','TD_jute_25','25',993,'fabrics/607c2a14cd5e455e1304b74e2bddc515.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(49,1,6,5,11,13,NULL,'Jute_18','TD_jute_18','18',993,'fabrics/cbe2b6a6d9610266b836bedb0683f6e7.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(50,1,6,5,11,10,NULL,'Jute_7','TD_jute_7','7',993,'fabrics/ef4bbf0fc53e3344910f4f0a8bffe45c.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(51,1,6,5,18,10,NULL,'Jute_2','TD_jute_2','2',993,'fabrics/7baf44c238d395c26fab380a666c0720.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(52,1,4,4,4,13,15,'Idol_125_rapport','TD_idol_125','125',1223,'fabrics/720d7c5c805ea09f5d3ac70b8fdb9342.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(53,1,4,4,7,13,NULL,'Idol_124_rapport','TD_idol_124','124',1223,'fabrics/3951dd90e5c3f9e172c2721a0e3437da.jpg','2020-10-14 12:35:31','2020-10-18 09:56:09'),(54,1,4,4,12,13,NULL,'Idol_117_rapport','TD_idol_117','117',1223,'fabrics/7299433758179a1d35ee5058f8164edd.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(55,1,4,4,6,13,NULL,'Idol_109_rapport','TD_idol_109','109',1223,'fabrics/cfd3c38b7d2ead8f34a7809a66b6c0fa.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(56,1,4,4,6,13,NULL,'Idol_108_rapport','TD_idol_108','108',1223,'fabrics/37c1f1adbdd44ba2afcc0767f0e5b5e1.jpg','2020-10-14 12:35:31','2020-10-18 09:56:09'),(57,1,4,4,18,10,NULL,'Idol_105_rapport','TD_idol_105','105',1223,'fabrics/d8f02bb0fb6cfa442d2a75b08563592a.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(58,1,4,4,18,10,NULL,'Idol_102_rapport','TD_idol_102','102',1223,'fabrics/33d78cc9af488e4db700f0893d159fea.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(59,1,4,4,11,10,NULL,'Idol_101_rapport','TD_idol_101','101',1223,'fabrics/a8c361c37f0dbad50c116fe69f8bbb66.jpg','2020-10-14 12:35:31','2020-10-18 09:56:08'),(60,1,4,4,12,13,NULL,'Idol_115_rapport','TD_idol_115','115',1223,'fabrics/ef719b208f1331e907a365f9cd80b918.jpg','2020-10-14 12:35:31','2020-10-18 10:07:57'),(61,1,3,1,6,13,NULL,'carboni_opera_14_rapport','TD_carboniopera_14','14',2003,'fabrics/ac845c2ea9a255d8b1fe8d71d9d628ae.jpg','2020-10-14 12:35:31','2020-10-18 10:06:01'),(62,1,3,1,4,17,1,'carboni_opera_11_rapport','TD_carboniopera_11','11',2003,'fabrics/9aa3544817a7cb9f82457738edcad4a7.jpg','2020-10-14 12:35:31','2020-10-18 10:04:43'),(63,1,3,3,6,13,NULL,'chanel_12_rapport.','TD_chanel_12','12',2241,'fabrics/66eb4559a50ede7b503d619da755fb5c.jpg','2020-10-14 12:35:31','2020-10-17 11:06:42'),(64,1,3,2,4,10,NULL,'carboni_placida_11_rapport','TD_carboniplacida_11','11-23',2003,'fabrics/91373732f05c8402f9ec1e4ac059330f.jpg','2020-10-14 12:35:31','2020-10-17 10:58:47');
/*!40000 ALTER TABLE `fabrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fabrics_types`
--

DROP TABLE IF EXISTS `fabrics_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fabrics_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fabrics_types`
--

LOCK TABLES `fabrics_types` WRITE;
/*!40000 ALTER TABLE `fabrics_types` DISABLE KEYS */;
INSERT INTO `fabrics_types` VALUES (2,'Велюр',NULL,'2020-10-13 05:07:57','2020-10-18 10:14:57'),(3,'Жаккард',NULL,'2020-10-13 05:08:02','2020-10-13 05:08:02'),(4,'Искусственная замша',NULL,'2020-10-13 05:08:06','2020-10-13 05:08:06'),(5,'Микрофибра',NULL,'2020-10-13 05:08:12','2020-10-13 05:08:12'),(6,'РогожкаА фыафыва',NULL,'2020-10-13 05:08:16','2020-10-15 11:51:08'),(7,'Шенилл',NULL,'2020-10-13 05:08:21','2020-10-16 08:41:31');
/*!40000 ALTER TABLE `fabrics_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materials` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `unit` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materials`
--

LOCK TABLES `materials` WRITE;
/*!40000 ALTER TABLE `materials` DISABLE KEYS */;
INSERT INTO `materials` VALUES (2,'mdfLaminated_3','мдф ламинированный 3 мм',97.00,'кв м','2020-10-09 05:38:41','2020-10-09 05:41:08'),(3,'hardboard','Оргалит',58.00,'кв м','2020-10-09 05:43:33','2020-10-09 05:43:33'),(4,'plywood_4','Фанера 4',207.00,'кв м','2020-10-09 05:46:50','2020-10-09 05:46:50'),(5,'plywood_9','Фанера 9',329.00,'кв м','2020-10-09 05:47:11','2020-10-09 05:47:11'),(6,'plywood_15','Фанера 15',490.00,'кв м','2020-10-09 05:47:34','2020-10-09 05:47:34'),(7,'plywood_21','Фанера 21',781.00,'кв м','2020-10-09 05:47:53','2020-10-09 05:47:53'),(8,'bar_30_40','Брусок 30*40',20.00,'м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(9,'foam_rubber_40_65_10','Поролон 40/65 10 мм',155.00,'кв м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(10,'foam_rubber_40_65_20','Поролон 40/65 20 мм',310.00,'кв м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(11,'foam_rubber_20','Поролон 20',200.00,'кв м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(12,'foam_rubber_5','Поролон 5',50.00,'кв м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(13,'theCloth','Ткань',950.00,'п м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(14,'theNut','Гайка',10.00,'шт','2020-10-09 05:48:17','2020-10-09 05:48:17'),(15,'theBolt','Болт',10.00,'шт','2020-10-09 05:48:17','2020-10-09 05:48:17'),(16,'ratchetMechanism','Механизм Трещотка',550.00,'шт','2020-10-09 05:48:17','2020-10-09 05:48:17'),(17,'theStaple','Скоба',0.40,'шт','2020-10-09 05:48:17','2020-10-09 05:48:17'),(18,'foamGlue','Клей для поролона',180.00,'л','2020-10-09 05:48:17','2020-10-09 05:48:17'),(19,'spandBond','Спандбонд',9.00,'п м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(20,'periotec','Периотек',100.00,'п м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(21,'velcro','Липучка',12.00,'м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(22,'PVA','ПВА',225.00,'л','2020-10-09 05:48:17','2020-10-09 05:48:17'),(23,'ribbon_60','Лента 60',26.00,'м','2020-10-09 05:48:17','2020-10-12 12:27:47'),(24,'spring','Пружина',40.00,'м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(25,'fabricSpandbond','Ткань - спандбонд',38.00,'кв м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(26,'foamRubber_35_42_40','Поролон 35/42 40 мм',500.00,'кв м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(27,'foamRubber_30_30_40','Поролон 30/30 40 мм',460.00,'кв м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(28,'foamRubberMemory_40_10_40','Поролон Мемори 40/10 40 мм',1150.00,'кв м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(29,'foamRubberMemory_50_14_40','Поролон Мемори 50/14 40 мм',1080.00,'кв м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(30,'holcon_20','Холкон 20',60.00,'кв м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(31,'theFelt','Войлок',105.00,'кв м','2020-10-09 05:48:17','2020-10-09 05:48:17'),(32,'metallicProfile','Металлический профиль',80.00,'м','2020-10-09 05:48:17','2020-10-09 05:48:17');
/*!40000 ALTER TABLE `materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `order_column` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,'App\\Models\\Product',4,'7482a6c4-4067-41e3-af8d-3c4ab270132c','default','1','1.jpg','image/jpeg','public','public',234087,'[]','[]','[]',1,'2020-10-07 11:21:48','2020-10-07 11:21:48'),(2,'App\\Models\\Product',4,'63463c10-ae6a-4c21-abf8-fff5cac4b73c','default','2','2.jpg','image/jpeg','public','public',239609,'[]','[]','[]',2,'2020-10-07 11:22:43','2020-10-07 11:22:43'),(3,'App\\Models\\Product',4,'7528ff83-5122-496f-b165-b7cf44c607b5','default','3','3.jpg','image/jpeg','public','public',237913,'[]','[]','[]',3,'2020-10-07 11:22:56','2020-10-07 11:22:56'),(4,'App\\Models\\Product',5,'6ccb90b9-036f-46d9-b16d-a571eeb3c89c','big','2','2.jpg','image/jpeg','public','public',7919,'[]','[]','[]',4,'2020-10-08 04:24:02','2020-10-08 04:24:02'),(5,'App\\Models\\Product',5,'c0f132fb-f462-4bd3-8a25-2d10e7719026','big','3','3.jpg','image/jpeg','public','public',8518,'[]','[]','[]',5,'2020-10-08 04:25:33','2020-10-08 04:25:33'),(6,'App\\Models\\Product',5,'d7ca4800-82fc-48be-b5de-49fa1b894b2c','big','121212','121212.jpg','image/jpeg','public','public',7919,'[]','[]','[]',6,'2020-10-08 04:27:26','2020-10-08 04:27:26'),(7,'App\\Models\\Product',5,'1db4bd8f-9df4-445c-b572-88e3eb362793','big','1','1.jpg','image/jpeg','public','public',9725,'[]','[]','[]',7,'2020-10-08 04:31:41','2020-10-08 04:31:41'),(8,'App\\Models\\Product',5,'a74771f2-9e04-457d-8fdb-88beda00772e','big','3','3.jpg','image/jpeg','public','public',8518,'[]','[]','[]',8,'2020-10-08 04:31:41','2020-10-08 04:31:41'),(9,'App\\Models\\Product',5,'7366cf92-eae1-404a-b8ae-4768db4bd45f','big','121212','121212.jpg','image/jpeg','public','public',7919,'[]','[]','[]',9,'2020-10-08 04:31:41','2020-10-08 04:31:41'),(10,'App\\Models\\Product',21,'f298ec20-1cdd-470c-816b-85f35c6954ae','big','NordicS','NordicS.jpg','image/jpeg','public','public',76762,'[]','[]','[]',10,'2020-10-28 15:16:07','2020-10-28 15:16:07'),(11,'App\\Models\\Product',21,'15003abd-4f24-4a09-b7c6-3d17a5bb2a05','big','series_logo','series_logo.jpg','image/jpeg','public','public',29008,'[]','[]','[]',11,'2020-10-28 15:16:07','2020-10-28 15:16:07');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2020_03_31_114745_remove_backpackuser_model',1),(5,'2020_10_03_140802_create_permission_tables',1),(6,'2020_10_07_071226_creaate_configuration_settings',1),(7,'2020_10_07_073938_create_configuration_sizes',1),(8,'2020_10_07_075758_creaate_configuration_legs',1),(9,'2020_10_07_075815_creaate_configuration_mechanisms',1),(10,'2020_10_07_075836_creaate_configuration_softness_sofas',1),(11,'2020_10_07_075856_creaate_configuration_textures',1),(12,'2020_10_07_080351_create_configuration_colors',1),(13,'2020_10_07_095847_create_pages',1),(14,'2020_10_07_101920_create_categories_table',1),(15,'2020_10_07_115140_create_products_table',1),(16,'2020_10_07_115517_add_field_products_table',1),(17,'2020_10_07_120212_add_field_to_products_table',1),(18,'2020_10_07_132244_create_media_table',1),(19,'2020_10_09_082930_create_material_table',1),(20,'2020_10_12_152345_create_activity_log_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (3,'App\\User',1),(5,'App\\User',8),(5,'App\\User',9),(2,'App\\User',10),(3,'App\\User',10);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `parent_id` int(11) DEFAULT '0',
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'Ред-е док','web','2020-10-11 10:28:11','2020-10-11 10:28:11');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producers`
--

DROP TABLE IF EXISTS `producers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `producers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producers`
--

LOCK TABLES `producers` WRITE;
/*!40000 ALTER TABLE `producers` DISABLE KEYS */;
INSERT INTO `producers` VALUES (1,'Текстиль Дата',NULL,'2020-10-13 05:12:57','2020-10-13 05:12:57'),(3,'12',NULL,'2020-10-16 08:41:48','2020-10-16 08:41:48');
/*!40000 ALTER TABLE `producers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0',
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `setting_options` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'2020-10-07 09:09:43','2020-10-09 06:13:23','Див1','magnum1',0,NULL,NULL,NULL,NULL,1,NULL,''),(4,'2020-10-07 09:09:48','2020-10-13 16:02:12','Диван Магнум','magnum2',0,NULL,NULL,NULL,NULL,1,NULL,'[\"metal_in_base\",\"tape_armrest\",\"left_armrest\",\"tape_back\",\"solid_wood_drawer\",\"tape_base\",\"metal_in_back\",\"right_armrest\",\"bar_in_armrest\",\"metal_in_armrest\",\"bar_in_back\",\"bar_in_base\"]'),(5,'2020-10-07 09:11:05','2020-10-09 06:12:58','Див31','magnum31',0,NULL,NULL,NULL,NULL,1,NULL,''),(20,'2020-10-09 06:25:45','2020-10-28 07:44:33','Див2-asdfasdf sa-df asd fsdf','magnum2',0,NULL,NULL,NULL,NULL,1,NULL,'[\"metal_in_back\",\"tape_armrest\",\"solid_wood_drawer\",\"tape_base\",\"right_armrest\",\"left_armrest\",\"tape_back\",\"metal_in_armrest\",\"bar_in_base\",\"bar_in_back\",\"metal_in_base\",\"bar_in_armrest\"]'),(21,'2020-10-28 07:55:52','2020-10-28 08:08:17','Название 1','nazvanie-1',0,NULL,NULL,NULL,NULL,1,NULL,'[\"metal_in_base\"]');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,2),(1,3);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (2,'admin','web','2020-10-11 10:25:11','2020-10-11 10:25:11'),(3,'superadmin','web','2020-10-11 10:25:20','2020-10-11 10:25:20'),(4,'manage','web','2020-10-11 10:25:44','2020-10-11 10:25:44'),(5,'client','web','2020-10-11 11:20:20','2020-10-11 11:20:30');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sofas`
--

DROP TABLE IF EXISTS `sofas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sofas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `slug` varchar(100) NOT NULL,
  `legs` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `under1` varchar(255) DEFAULT NULL,
  `under2` varchar(255) DEFAULT NULL,
  `under3` varchar(255) DEFAULT NULL,
  `under4` varchar(255) DEFAULT NULL,
  `amountDiscount` int(11) DEFAULT NULL,
  `discount` tinyint(1) NOT NULL DEFAULT '0',
  `oldPrice` int(11) DEFAULT NULL,
  `newPrice` int(11) DEFAULT NULL,
  `fabric` varchar(255) DEFAULT NULL,
  `mechanism` tinyint(1) NOT NULL DEFAULT '0',
  `fittings` varchar(255) DEFAULT NULL,
  `nlike` tinyint(1) NOT NULL DEFAULT '0',
  `profit` int(11) DEFAULT '200',
  `setting_options` text,
  `back_height` int(11) DEFAULT NULL,
  `back_thickness` int(11) DEFAULT NULL,
  `armrest_thickness` int(11) DEFAULT NULL,
  `armrest_height` int(11) DEFAULT NULL,
  `armrest_width` int(11) DEFAULT NULL,
  `side_bar_height` int(11) DEFAULT NULL,
  `cushion_thickness` int(11) DEFAULT NULL,
  `image_description` varchar(255) DEFAULT NULL,
  `config` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sofas`
--

LOCK TABLES `sofas` WRITE;
/*!40000 ALTER TABLE `sofas` DISABLE KEYS */;
INSERT INTO `sofas` VALUES (1,NULL,'andria-divan-s-ottomankoy',1,'Andria - Диван с оттоманкой','uploads/sofa/andria-divan-s-ottomankoy/6795075c75ca142e63c4b6bc6599b0ef.jpg','http://sdelay.online/img/andria/image-under-1.png','http://sdelay.online/img/andria/image-under-2.png','http://sdelay.online/img/andria/image-under-3.png','http://sdelay.online/img/andria/image-under-4.png',20,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,'[\"metal_in_back\",\"hard_covering\",\"zipper\",\"metal_in_base\",\"legs\",\"calico\",\"down_natural\",\"solid_wood_drawer\",\"tape_base\",\"tape_back\",\"tape_armrest\",\"right_armrest\",\"left_armrest\",\"folding_mechanism\",\"metal_in_armrest\",\"mechanism_in_armrests\",\"bar_in_armrest\",\"bar_in_base\",\"bar_in_back\"]',101,102,103,104,105,106,107,'Et molestiae veritatis quasi ut velit odio. Nihil qui hic labore rerum dolor.','ottoman','2020-11-03 10:43:51','2020-11-03 07:43:51'),(2,NULL,'asti-divan-s-ottomankoy',1,'Asti - Диван с оттоманкой','uploads/sofa/asti-divan-s-ottomankoy/a763a5e237fa387304b586d7922645ee.jpg','http://sdelay.online/img/asti/image-under-1.png','http://sdelay.online/img/asti/image-under-2.png','http://sdelay.online/img/asti/image-under-3.png','http://sdelay.online/img/asti/image-under-4.png',20,0,0,60000,'Текстиль, кожа',1,'Дерево',1,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sit placeat in consequuntur. Id et aut amet ipsam. Et consequatur ea dolor neque maiores.','ottoman','2020-11-03 10:46:22','2020-11-03 07:46:22'),(3,NULL,'barbaro-divan-s-ottomankoy',1,'Barbaro - Диван с оттоманкой','uploads/sofa/barbaro-divan-s-ottomankoy/349460d00cfb04c9acc0363bd1a1e817.jpg','http://sdelay.online/img/barbaro/image-under-1.png','http://sdelay.online/img/barbaro/image-under-2.png','http://sdelay.online/img/barbaro/image-under-3.png','http://sdelay.online/img/barbaro/image-under-4.png',20,0,0,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Necessitatibus a placeat perspiciatis neque ea. Voluptas voluptatem id quia autem voluptatibus.','ottoman','2020-11-03 10:47:35','2020-11-03 07:47:35'),(4,NULL,'bossi-divan-s-ottomankoy',1,'Bossi - Диван с оттоманкой\n\r','http://sdelay.online/img/bossi/bossi-main.png','http://sdelay.online/img/bossi/image-under-1.png','http://sdelay.online/img/bossi/image-under-2.png','http://sdelay.online/img/bossi/image-under-3.png','http://sdelay.online/img/bossi/image-under-4.png',10,1,90000,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Quis animi quae qui. Mollitia nulla ut exercitationem. Sint facilis fugit non voluptas aut.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(5,NULL,'bari-divan-s-ottomankoy',1,'Bari - Диван с оттоманкой','uploads/sofa/bari-divan-s-ottomankoy/bb9febf82f70f17dc0d0bf4230158fce.jpg','http://sdelay.online/img/bari/image-under-1.png','http://sdelay.online/img/bari/image-under-2.png','http://sdelay.online/img/bari/image-under-3.png','http://sdelay.online/img/bari/image-under-4.png',10,1,90000,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sint veniam sint officia qui. Aspernatur sit commodi qui et tempora similique.','ottoman','2020-11-03 10:49:50','2020-11-03 07:49:50'),(6,NULL,'carpi-divan-s-ottomankoy',0,'Carpi - Диван с оттоманкой\n\r','http://sdelay.online/img/carpi/carpi-main.png','http://sdelay.online/img/carpi/image-under-1.png','http://sdelay.online/img/carpi/image-under-2.png','http://sdelay.online/img/carpi/image-under-3.png','http://sdelay.online/img/carpi/image-under-4.png',18,1,90000,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Est consequatur consequatur reprehenderit. Tenetur laudantium maxime similique cum sit veniam in.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(7,NULL,'chesterfield-divan-s-ottomankoy',1,'Chesterfield - Диван с оттоманкой\n\r','http://sdelay.online/img/chesterfield/chesterfield-main.png','http://sdelay.online/img/chesterfield/image-under-1.png','http://sdelay.online/img/chesterfield/image-under-2.png','http://sdelay.online/img/chesterfield/image-under-3.png','http://sdelay.online/img/chesterfield/image-under-4.png',20,1,90000,60000,'Текстиль, кожа',0,'Дерево',1,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Iste error aut rerum placeat. Perferendis iure qui ratione rem qui et.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(8,NULL,'classic-sofa-divan-s-ottomankoy',1,'Classic-sofa - Диван с оттоманкой\n\r','http://sdelay.online/img/classic-sofa/classic-sofa-main.png','http://sdelay.online/img/classic-sofa/image-under-1.png','http://sdelay.online/img/classic-sofa/image-under-2.png','http://sdelay.online/img/classic-sofa/image-under-3.png','http://sdelay.online/img/classic-sofa/image-under-4.png',14,0,0,80000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Enim minus culpa aut autem. Voluptas cupiditate ad eos ut id. Deserunt nisi nihil et eos.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(9,NULL,'como-divan-s-ottomankoy',0,'Como - Диван с оттоманкой\n\r','http://sdelay.online/img/como/como-main.png','http://sdelay.online/img/como/image-under-1.png','http://sdelay.online/img/como/image-under-2.png','http://sdelay.online/img/como/image-under-3.png','http://sdelay.online/img/como/image-under-4.png',14,0,0,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Similique delectus sunt reprehenderit magnam sed ut. Aliquid id ea velit et ea ut.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(10,NULL,'eko-divan-s-ottomankoy',1,'Eko - Диван с оттоманкой\n\r','http://sdelay.online/img/eko/eko-main.png','http://sdelay.online/img/eko/image-under-1.png','http://sdelay.online/img/eko/image-under-2.png','http://sdelay.online/img/eko/image-under-3.png','http://sdelay.online/img/eko/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Et laborum ut enim quo. Non officia corporis est id et. Labore magnam quia corporis dicta.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(11,NULL,'ferrara-divan-s-ottomankoy',1,'Ferrara - Диван с оттоманкой\n\r','http://sdelay.online/img/ferrara/ferrara-main.png','http://sdelay.online/img/ferrara/image-under-1.png','http://sdelay.online/img/ferrara/image-under-2.png','http://sdelay.online/img/ferrara/image-under-3.png','http://sdelay.online/img/ferrara/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Quia aut ratione officia ducimus. Unde quis doloremque sunt ea aliquid deleniti voluptatem.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(12,NULL,'florence-divan-s-ottomankoy',1,'Florence - Диван с оттоманкой\n\r','http://sdelay.online/img/florence/florence-main.png','http://sdelay.online/img/florence/image-under-1.png','http://sdelay.online/img/florence/image-under-2.png','http://sdelay.online/img/florence/image-under-3.png','http://sdelay.online/img/florence/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cupiditate quia iure quia saepe quia. Delectus ex commodi aut. Et cum ratione a ut.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(13,NULL,'forli-divan-s-ottomankoy',0,'Forli - Диван с оттоманкой\n\r','http://sdelay.online/img/forli/forli-main.png','http://sdelay.online/img/forli/image-under-1.png','http://sdelay.online/img/forli/image-under-2.png','http://sdelay.online/img/forli/image-under-3.png','http://sdelay.online/img/forli/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Accusantium ipsum est soluta a. Ducimus expedita sint atque.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(14,NULL,'imola-divan-s-ottomankoy',0,'Imola - Диван с оттоманкой\n\r','http://sdelay.online/img/imola/imola-main.png','http://sdelay.online/img/imola/image-under-1.png','http://sdelay.online/img/imola/image-under-2.png','http://sdelay.online/img/imola/image-under-3.png','http://sdelay.online/img/imola/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ut quibusdam ut sequi quo. Sit optio autem nihil aut illo delectus. Ut voluptatem cumque et.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(15,NULL,'kapella-divan-s-ottomankoy',1,'Kapella - Диван с оттоманкой\n\r','http://sdelay.online/img/kapella/kapella-main.png','http://sdelay.online/img/kapella/image-under-1.png','http://sdelay.online/img/kapella/image-under-2.png','http://sdelay.online/img/kapella/image-under-3.png','http://sdelay.online/img/kapella/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Rerum iure harum enim ut doloremque maxime molestias. Quos ratione non laborum quo ad excepturi.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(16,NULL,'livorno-divan-s-ottomankoy',1,'Livorno - Диван с оттоманкой\n\r','http://sdelay.online/img/livorno/livorno-main.png','http://sdelay.online/img/livorno/image-under-1.png','http://sdelay.online/img/livorno/image-under-2.png','http://sdelay.online/img/livorno/image-under-3.png','http://sdelay.online/img/livorno/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Molestias animi quo ex animi harum deserunt. Doloribus consequatur molestiae illum nisi et.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(17,NULL,'monza-divan-s-ottomankoy',1,'Monza - Диван с оттоманкой\n\r','http://sdelay.online/img/monza/monza-main.png','http://sdelay.online/img/monza/image-under-1.png','http://sdelay.online/img/monza/image-under-2.png','http://sdelay.online/img/monza/image-under-3.png','http://sdelay.online/img/monza/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Eos qui qui consequatur reiciendis. Doloribus et cupiditate molestiae distinctio non enim.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(18,NULL,'muni-divan-s-ottomankoy',1,'Muni - Диван с оттоманкой\n\r','http://sdelay.online/img/muni/muni-main.png','http://sdelay.online/img/muni/image-under-1.png','http://sdelay.online/img/muni/image-under-2.png','http://sdelay.online/img/muni/image-under-3.png','http://sdelay.online/img/muni/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Porro eos non repellendus. Ratione necessitatibus et non sed. Quo porro dolores quia mollitia.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(19,NULL,'parma-pryamoy-divan',1,'Parma - Прямой диван\n\r','http://sdelay.online/img/parma/parma-main.png','http://sdelay.online/img/parma/image-under-1.png','http://sdelay.online/img/parma/image-under-2.png','http://sdelay.online/img/parma/image-under-3.png','http://sdelay.online/img/parma/image-under-4.png',11,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Omnis earum voluptatum quo voluptas. Quis et aut voluptatem.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(20,NULL,'terni-divan-s-ottomankoy',1,'Terni - Диван с оттоманкой\n\r','http://sdelay.online/img/terni/terni-main.png','http://sdelay.online/img/terni/image-under-1.png','http://sdelay.online/img/terni/image-under-2.png','http://sdelay.online/img/terni/image-under-3.png','http://sdelay.online/img/terni/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Alias sit veniam minima voluptatem. Esse perferendis officia eaque nihil iste quia.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(21,NULL,'turin-divan-s-ottomankoy',0,'Turin - Диван с оттоманкой\n\r','http://sdelay.online/img/turin/turin-main.png','http://sdelay.online/img/turin/image-under-1.png','http://sdelay.online/img/turin/image-under-2.png','http://sdelay.online/img/turin/image-under-3.png','http://sdelay.online/img/turin/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nihil quasi consectetur quas eligendi optio. Sint inventore qui nulla doloremque quos dolores qui.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(23,NULL,'andria-uglovoy-divan',1,'Andria - Угловой диван','uploads/sofa/andria-uglovoy-divan/1b592356d7d337dc7611d0a9dc9ace36.jpg','http://sdelay.online/img/andria/image-under-1.png','http://sdelay.online/img/andria/image-under-2.png','http://sdelay.online/img/andria/image-under-3.png','http://sdelay.online/img/andria/image-under-4.png',20,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,'[\"metal_in_back\",\"hard_covering\",\"zipper\",\"metal_in_base\",\"legs\",\"calico\",\"down_natural\",\"solid_wood_drawer\",\"tape_base\",\"tape_back\",\"tape_armrest\",\"right_armrest\",\"left_armrest\",\"folding_mechanism\",\"metal_in_armrest\",\"mechanism_in_armrests\",\"bar_in_armrest\",\"bar_in_base\",\"bar_in_back\"]',101,102,103,104,105,106,107,'Mollitia ab id rerum est rerum. Ullam soluta culpa officia. In sapiente laboriosam dicta et.','angle','2020-11-03 10:45:26','2020-11-03 07:45:26'),(24,NULL,'andria-pryamoy-divan',1,'Andria - Прямой диван','uploads/sofa/andria-pryamoy-divan/792fe47181fdce3c3b1120e3adb83a10.jpg','http://sdelay.online/img/andria/image-under-1.png','http://sdelay.online/img/andria/image-under-2.png','http://sdelay.online/img/andria/image-under-3.png','http://sdelay.online/img/andria/image-under-4.png',20,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,'[\"metal_in_back\",\"hard_covering\",\"zipper\",\"metal_in_base\",\"legs\",\"calico\",\"down_natural\",\"solid_wood_drawer\",\"tape_base\",\"tape_back\",\"tape_armrest\",\"right_armrest\",\"left_armrest\",\"folding_mechanism\",\"metal_in_armrest\",\"mechanism_in_armrests\",\"bar_in_armrest\",\"bar_in_base\",\"bar_in_back\"]',101,102,103,104,105,106,107,'Veritatis harum quas autem earum dolorem veniam ut. Culpa odit dignissimos est eos.','straight','2020-11-03 10:44:16','2020-11-03 07:44:16'),(25,NULL,'asti-uglovoy-divan',1,'Asti - Угловой диван','uploads/sofa/asti-uglovoy-divan/11e4cee05675c7bc8e86716001454928.jpg','http://sdelay.online/img/asti/image-under-1.png','http://sdelay.online/img/asti/image-under-2.png','http://sdelay.online/img/asti/image-under-3.png','http://sdelay.online/img/asti/image-under-4.png',20,0,0,60000,'Текстиль, кожа',1,'Дерево',1,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Et dolor dolorum excepturi ipsa odit. Eos voluptatum veritatis quod eaque.','angle','2020-11-03 10:46:57','2020-11-03 07:46:57'),(26,NULL,'asti-pryamoy-divan',1,'Asti - Прямой диван\n\r','http://sdelay.online/img/asti/asti-main.png','http://sdelay.online/img/asti/image-under-1.png','http://sdelay.online/img/asti/image-under-2.png','http://sdelay.online/img/asti/image-under-3.png','http://sdelay.online/img/asti/image-under-4.png',20,0,0,60000,'Текстиль, кожа',1,'Дерево',1,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Qui illo et autem minus dolorem sit ea. Est cupiditate unde est at est et excepturi.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(27,NULL,'barbaro-uglovoy-divan',1,'Barbaro - Угловой диван','uploads/sofa/barbaro-uglovoy-divan/e1a86ac1b5aabc0ca3c37455c80b5ea4.jpg','http://sdelay.online/img/barbaro/image-under-1.png','http://sdelay.online/img/barbaro/image-under-2.png','http://sdelay.online/img/barbaro/image-under-3.png','http://sdelay.online/img/barbaro/image-under-4.png',20,0,0,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Consequatur totam voluptatum quo molestiae sit. Magnam quos atque eos pariatur soluta voluptatum.','angle','2020-11-03 10:48:24','2020-11-03 07:48:24'),(28,NULL,'barbaro-pryamoy-divan',1,'Barbaro - Прямой диван\n\r','http://sdelay.online/img/barbaro/barbaro-main.png','http://sdelay.online/img/barbaro/image-under-1.png','http://sdelay.online/img/barbaro/image-under-2.png','http://sdelay.online/img/barbaro/image-under-3.png','http://sdelay.online/img/barbaro/image-under-4.png',20,0,0,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Maiores est magnam blanditiis quo odio similique. Sit et quam ullam a.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(29,NULL,'bari-uglovoy-divan',1,'Bari - Угловой диван','uploads/sofa/bari-uglovoy-divan/58b391edbe5f05c4817f1f237e709003.jpg','http://sdelay.online/img/bari/image-under-1.png','http://sdelay.online/img/bari/image-under-2.png','http://sdelay.online/img/bari/image-under-3.png','http://sdelay.online/img/bari/image-under-4.png',10,1,90000,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Omnis expedita sit eum quo voluptatibus id neque. Aut culpa unde repellendus est aut et.','angle','2020-11-03 10:50:17','2020-11-03 07:50:17'),(30,NULL,'bari-pryamoy-divan',1,'Bari - Прямой диван\n\r','http://sdelay.online/img/bari/bari-main.png','http://sdelay.online/img/bari/image-under-1.png','http://sdelay.online/img/bari/image-under-2.png','http://sdelay.online/img/bari/image-under-3.png','http://sdelay.online/img/bari/image-under-4.png',10,1,90000,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Accusantium vel et sapiente esse. Voluptatibus ea tempore suscipit.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(31,NULL,'bossi-uglovoy-divan',1,'Bossi - Угловой диван\n\r','http://sdelay.online/img/bossi/bossi-main.png','http://sdelay.online/img/bossi/image-under-1.png','http://sdelay.online/img/bossi/image-under-2.png','http://sdelay.online/img/bossi/image-under-3.png','http://sdelay.online/img/bossi/image-under-4.png',10,1,90000,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Illo reiciendis blanditiis illo officiis deserunt ut placeat. Voluptate totam quos magni.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(32,NULL,'bossi-pryamoy-divan',1,'Bossi - Прямой диван\n\r','http://sdelay.online/img/bossi/bossi-main.png','http://sdelay.online/img/bossi/image-under-1.png','http://sdelay.online/img/bossi/image-under-2.png','http://sdelay.online/img/bossi/image-under-3.png','http://sdelay.online/img/bossi/image-under-4.png',10,1,90000,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Adipisci maxime quia non voluptatibus. Aperiam at quia sapiente facere mollitia vel.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(33,NULL,'carpi-uglovoy-divan',0,'Carpi - Угловой диван\n\r','http://sdelay.online/img/carpi/carpi-main.png','http://sdelay.online/img/carpi/image-under-1.png','http://sdelay.online/img/carpi/image-under-2.png','http://sdelay.online/img/carpi/image-under-3.png','http://sdelay.online/img/carpi/image-under-4.png',18,1,90000,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Veritatis sed et magnam qui laboriosam. Dolor tempore ducimus iste nisi totam eum voluptatibus.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(34,NULL,'carpi-pryamoy-divan',0,'Carpi - Прямой диван\n\r','http://sdelay.online/img/carpi/carpi-main.png','http://sdelay.online/img/carpi/image-under-1.png','http://sdelay.online/img/carpi/image-under-2.png','http://sdelay.online/img/carpi/image-under-3.png','http://sdelay.online/img/carpi/image-under-4.png',18,1,90000,60000,'Текстиль, кожа',0,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Rem harum temporibus id veniam pariatur. Et et nihil reprehenderit et. Rerum ut a ipsa.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(35,NULL,'chesterfield-uglovoy-divan',1,'Chesterfield - Угловой диван\n\r','http://sdelay.online/img/chesterfield/chesterfield-main.png','http://sdelay.online/img/chesterfield/image-under-1.png','http://sdelay.online/img/chesterfield/image-under-2.png','http://sdelay.online/img/chesterfield/image-under-3.png','http://sdelay.online/img/chesterfield/image-under-4.png',20,1,90000,60000,'Текстиль, кожа',0,'Дерево',1,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Rem enim animi unde dolor qui qui et. Iusto sunt fugit optio nam voluptatem id tempora.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(36,NULL,'chesterfield-pryamoy-divan',1,'Chesterfield - Прямой диван\n\r','http://sdelay.online/img/chesterfield/chesterfield-main.png','http://sdelay.online/img/chesterfield/image-under-1.png','http://sdelay.online/img/chesterfield/image-under-2.png','http://sdelay.online/img/chesterfield/image-under-3.png','http://sdelay.online/img/chesterfield/image-under-4.png',20,1,90000,60000,'Текстиль, кожа',0,'Дерево',1,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Odio qui sit distinctio. Qui quibusdam omnis voluptas. Cum sed quia similique doloribus nemo.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(37,NULL,'classic-sofa-uglovoy-divan',1,'Classic-sofa - Угловой диван\n\r','http://sdelay.online/img/classic-sofa/classic-sofa-main.png','http://sdelay.online/img/classic-sofa/image-under-1.png','http://sdelay.online/img/classic-sofa/image-under-2.png','http://sdelay.online/img/classic-sofa/image-under-3.png','http://sdelay.online/img/classic-sofa/image-under-4.png',14,0,0,80000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Molestiae mollitia ratione dolor qui. Nesciunt pariatur sed pariatur harum.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(38,NULL,'classic-sofa-pryamoy-divan',1,'Classic-sofa - Прямой диван\n\r','http://sdelay.online/img/classic-sofa/classic-sofa-main.png','http://sdelay.online/img/classic-sofa/image-under-1.png','http://sdelay.online/img/classic-sofa/image-under-2.png','http://sdelay.online/img/classic-sofa/image-under-3.png','http://sdelay.online/img/classic-sofa/image-under-4.png',14,0,0,80000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Rerum molestiae temporibus nisi iusto quos recusandae. Dolorum totam rem autem qui.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(39,NULL,'como-uglovoy-divan',0,'Como - Угловой диван\n\r','http://sdelay.online/img/como/como-main.png','http://sdelay.online/img/como/image-under-1.png','http://sdelay.online/img/como/image-under-2.png','http://sdelay.online/img/como/image-under-3.png','http://sdelay.online/img/como/image-under-4.png',14,0,0,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Iste et odio natus vitae rerum. Rem est iusto sit perspiciatis et.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(40,NULL,'como-pryamoy-divan',0,'Como - Прямой диван\n\r','http://sdelay.online/img/como/como-main.png','http://sdelay.online/img/como/image-under-1.png','http://sdelay.online/img/como/image-under-2.png','http://sdelay.online/img/como/image-under-3.png','http://sdelay.online/img/como/image-under-4.png',14,0,0,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Iusto vitae eaque voluptatem accusantium. Fuga sunt ut veritatis ut laboriosam dolor.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(41,NULL,'eko-uglovoy-divan',1,'Eko - Угловой диван\n\r','http://sdelay.online/img/eko/eko-main.png','http://sdelay.online/img/eko/image-under-1.png','http://sdelay.online/img/eko/image-under-2.png','http://sdelay.online/img/eko/image-under-3.png','http://sdelay.online/img/eko/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Fugit dolorem libero eum. Libero culpa sed dolores rerum occaecati. Nobis magnam quaerat aut aut.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(42,NULL,'eko-pryamoy-divan',1,'Eko - Прямой диван\n\r','http://sdelay.online/img/eko/eko-main.png','http://sdelay.online/img/eko/image-under-1.png','http://sdelay.online/img/eko/image-under-2.png','http://sdelay.online/img/eko/image-under-3.png','http://sdelay.online/img/eko/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Suscipit laboriosam labore beatae. Aut perspiciatis eaque velit et officia. Itaque nam alias et.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(43,NULL,'ferrara-uglovoy-divan',1,'Ferrara - Угловой диван\n\r','http://sdelay.online/img/ferrara/ferrara-main.png','http://sdelay.online/img/ferrara/image-under-1.png','http://sdelay.online/img/ferrara/image-under-2.png','http://sdelay.online/img/ferrara/image-under-3.png','http://sdelay.online/img/ferrara/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Dolorem aut odio omnis et ea voluptatem quae. Inventore quis at accusamus ut.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(44,NULL,'ferrara-pryamoy-divan',1,'Ferrara - Прямой диван\n\r','http://sdelay.online/img/ferrara/ferrara-main.png','http://sdelay.online/img/ferrara/image-under-1.png','http://sdelay.online/img/ferrara/image-under-2.png','http://sdelay.online/img/ferrara/image-under-3.png','http://sdelay.online/img/ferrara/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Voluptatibus et reprehenderit eveniet debitis. Ex et ea doloremque vel porro.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(45,NULL,'florence-uglovoy-divan',1,'Florence - Угловой диван\n\r','http://sdelay.online/img/florence/florence-main.png','http://sdelay.online/img/florence/image-under-1.png','http://sdelay.online/img/florence/image-under-2.png','http://sdelay.online/img/florence/image-under-3.png','http://sdelay.online/img/florence/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nisi accusamus sequi quidem sit. Sint tempore accusantium nihil. Atque aut non pariatur eos.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(46,NULL,'florence-pryamoy-divan',1,'Florence - Прямой диван\n\r','http://sdelay.online/img/florence/florence-main.png','http://sdelay.online/img/florence/image-under-1.png','http://sdelay.online/img/florence/image-under-2.png','http://sdelay.online/img/florence/image-under-3.png','http://sdelay.online/img/florence/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cum ducimus quia incidunt est. Sequi at sed quidem molestias odio vitae.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(47,NULL,'forli-uglovoy-divan',0,'Forli - Угловой диван\n\r','http://sdelay.online/img/forli/forli-main.png','http://sdelay.online/img/forli/image-under-1.png','http://sdelay.online/img/forli/image-under-2.png','http://sdelay.online/img/forli/image-under-3.png','http://sdelay.online/img/forli/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Qui aut et autem. Nam vitae voluptas totam.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(48,NULL,'forli-pryamoy-divan',0,'Forli - Прямой диван\n\r','http://sdelay.online/img/forli/forli-main.png','http://sdelay.online/img/forli/image-under-1.png','http://sdelay.online/img/forli/image-under-2.png','http://sdelay.online/img/forli/image-under-3.png','http://sdelay.online/img/forli/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed est blanditiis ut suscipit maiores. Hic vitae cumque quia illo quasi quo rerum.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(49,NULL,'imola-uglovoy-divan',0,'Imola - Угловой диван\n\r','http://sdelay.online/img/imola/imola-main.png','http://sdelay.online/img/imola/image-under-1.png','http://sdelay.online/img/imola/image-under-2.png','http://sdelay.online/img/imola/image-under-3.png','http://sdelay.online/img/imola/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ducimus ea doloribus recusandae. Amet saepe rem incidunt nesciunt.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(50,NULL,'imola-pryamoy-divan',0,'Imola - Прямой диван\n\r','http://sdelay.online/img/imola/imola-main.png','http://sdelay.online/img/imola/image-under-1.png','http://sdelay.online/img/imola/image-under-2.png','http://sdelay.online/img/imola/image-under-3.png','http://sdelay.online/img/imola/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Molestiae quibusdam facere alias dolor recusandae soluta ipsum. Eos nihil nemo inventore quas quo.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(51,NULL,'kapella-uglovoy-divan',1,'Kapella - Угловой диван\n\r','http://sdelay.online/img/kapella/kapella-main.png','http://sdelay.online/img/kapella/image-under-1.png','http://sdelay.online/img/kapella/image-under-2.png','http://sdelay.online/img/kapella/image-under-3.png','http://sdelay.online/img/kapella/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Praesentium numquam perspiciatis non. Et quas occaecati placeat est quis impedit.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(52,NULL,'kapella-pryamoy-divan',1,'Kapella - Прямой диван\n\r','http://sdelay.online/img/kapella/kapella-main.png','http://sdelay.online/img/kapella/image-under-1.png','http://sdelay.online/img/kapella/image-under-2.png','http://sdelay.online/img/kapella/image-under-3.png','http://sdelay.online/img/kapella/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Voluptatum minus omnis nam animi rerum. Ut expedita tempore voluptas dolorem.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(53,NULL,'livorno-uglovoy-divan',1,'Livorno - Угловой диван\n\r','http://sdelay.online/img/livorno/livorno-main.png','http://sdelay.online/img/livorno/image-under-1.png','http://sdelay.online/img/livorno/image-under-2.png','http://sdelay.online/img/livorno/image-under-3.png','http://sdelay.online/img/livorno/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ut esse sed quae culpa. Consectetur doloremque voluptates voluptatem eum id sit.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(54,NULL,'livorno-pryamoy-divan',1,'Livorno - Прямой диван\n\r','http://sdelay.online/img/livorno/livorno-main.png','http://sdelay.online/img/livorno/image-under-1.png','http://sdelay.online/img/livorno/image-under-2.png','http://sdelay.online/img/livorno/image-under-3.png','http://sdelay.online/img/livorno/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Impedit fugit repudiandae ab enim enim aperiam. Laborum architecto animi et esse quaerat.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(55,NULL,'monza-uglovoy-divan',1,'Monza - Угловой диван\n\r','http://sdelay.online/img/monza/monza-main.png','http://sdelay.online/img/monza/image-under-1.png','http://sdelay.online/img/monza/image-under-2.png','http://sdelay.online/img/monza/image-under-3.png','http://sdelay.online/img/monza/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'In quod aut ut officiis. Officia voluptate corporis rerum totam.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(56,NULL,'monza-pryamoy-divan',1,'Monza - Прямой диван\n\r','http://sdelay.online/img/monza/monza-main.png','http://sdelay.online/img/monza/image-under-1.png','http://sdelay.online/img/monza/image-under-2.png','http://sdelay.online/img/monza/image-under-3.png','http://sdelay.online/img/monza/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nam amet minima quo iure impedit. Dolor quaerat voluptas et est voluptatem numquam.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(57,NULL,'muni-uglovoy-divan',1,'Muni - Угловой диван\n\r','http://sdelay.online/img/muni/muni-main.png','http://sdelay.online/img/muni/image-under-1.png','http://sdelay.online/img/muni/image-under-2.png','http://sdelay.online/img/muni/image-under-3.png','http://sdelay.online/img/muni/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nam fugiat unde vel aliquid. Sequi nihil ut dignissimos eius expedita a. Est non ut aut est.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(58,NULL,'muni-pryamoy-divan',1,'Muni - Прямой диван\n\r','http://sdelay.online/img/muni/muni-main.png','http://sdelay.online/img/muni/image-under-1.png','http://sdelay.online/img/muni/image-under-2.png','http://sdelay.online/img/muni/image-under-3.png','http://sdelay.online/img/muni/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Similique unde quas hic qui. Aperiam consequatur ut esse tenetur aut molestias ut.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(59,NULL,'parma-divan-s-ottomankoy',1,'Parma - Диван с оттоманкой\n\r','http://sdelay.online/img/parma/parma-main.png','http://sdelay.online/img/parma/image-under-1.png','http://sdelay.online/img/parma/image-under-2.png','http://sdelay.online/img/parma/image-under-3.png','http://sdelay.online/img/parma/image-under-4.png',11,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'A culpa ipsum aliquid officia in. Deserunt natus sit ad. Atque libero voluptas alias.','ottoman','2020-11-03 09:26:00','2020-11-03 06:26:00'),(60,NULL,'parma-uglovoy-divan',1,'Parma - Угловой диван\n\r','http://sdelay.online/img/parma/parma-main.png','http://sdelay.online/img/parma/image-under-1.png','http://sdelay.online/img/parma/image-under-2.png','http://sdelay.online/img/parma/image-under-3.png','http://sdelay.online/img/parma/image-under-4.png',11,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Eius eos sit beatae magni eos ab quis. Velit provident blanditiis quis autem.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(61,NULL,'terni-uglovoy-divan',1,'Terni - Угловой диван\n\r','http://sdelay.online/img/terni/terni-main.png','http://sdelay.online/img/terni/image-under-1.png','http://sdelay.online/img/terni/image-under-2.png','http://sdelay.online/img/terni/image-under-3.png','http://sdelay.online/img/terni/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Dignissimos magni sed vero. Veritatis omnis ab rem dolore.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(62,NULL,'terni-pryamoy-divan',1,'Terni - Прямой диван\n\r','http://sdelay.online/img/terni/terni-main.png','http://sdelay.online/img/terni/image-under-1.png','http://sdelay.online/img/terni/image-under-2.png','http://sdelay.online/img/terni/image-under-3.png','http://sdelay.online/img/terni/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Dolorem incidunt iure consequatur consectetur tempore. Omnis est doloribus perferendis maiores.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00'),(63,NULL,'turin-uglovoy-divan',0,'Turin - Угловой диван\n\r','http://sdelay.online/img/turin/turin-main.png','http://sdelay.online/img/turin/image-under-1.png','http://sdelay.online/img/turin/image-under-2.png','http://sdelay.online/img/turin/image-under-3.png','http://sdelay.online/img/turin/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Architecto enim voluptate atque eaque impedit magnam. Est voluptatibus sit officiis provident.','angle','2020-11-03 09:26:00','2020-11-03 06:26:00'),(64,NULL,'turin-pryamoy-divan',0,'Turin - Прямой диван\n\r','http://sdelay.online/img/turin/turin-main.png','http://sdelay.online/img/turin/image-under-1.png','http://sdelay.online/img/turin/image-under-2.png','http://sdelay.online/img/turin/image-under-3.png','http://sdelay.online/img/turin/image-under-4.png',21,1,90000,60000,'Текстиль, кожа',1,'Дерево',0,200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Eos ipsa facere aut nihil et. Earum est quo ipsum aut ut est. Ut sit deserunt autem cum.','straight','2020-11-03 09:26:00','2020-11-03 06:26:00');
/*!40000 ALTER TABLE `sofas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'SerjK','a1@a1.ru',NULL,'$2y$10$Li5ZrlbEQO/Pnq64UyIRjuvhuFt0CzF4bwtu1LuKZ1nyCmGf0n85C','FW5Uq6b6JUmFQKlBinzEb2TkjyYjtdaThmVXX2Zh4dMFN95nqkrLoZDPznlV','2020-10-09 09:46:36','2020-10-11 10:27:21'),(8,'a8','a8@aaa.ru',NULL,'$2y$10$7RxZKQQlSwmJ5sCl0mBmCu6ybHfLSvaaFauykAUHoMc7bHza8qBpK',NULL,'2020-10-11 11:41:26','2020-10-11 11:41:26'),(9,'a10','a10@a.ru',NULL,'$2y$10$L4HsLKvNa4Wx3XRBTDO7ZeYekQbj/d4FeCbI2/5cMbGDRmtpKtTxO',NULL,'2020-10-11 11:42:37','2020-10-11 11:42:37'),(10,'Алексей','alexey@woodfans.ru',NULL,'$2y$10$uaggV1Nr2EhnoGo/t7QTvuFhyklUEqShtYuZNbKYYKbDCxwp2E8MK',NULL,'2020-10-12 07:50:42','2020-10-12 07:50:42');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-03 17:06:53
